﻿namespace WeatherApp.Models
{
    public class Location
    {
        public string location { get; set; }
    }
}
